<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Load Claude Connector language file
 * Properly loads the language file using Perfex CRM's standard method
 */
if (!function_exists('load_claude_connector_language')) {
    function load_claude_connector_language()
    {
        $CI = &get_instance();
        
        // Get current language
        $language = get_option('active_language');
        
        // If in admin area and staff is logged in, get their language
        if (is_admin() && is_staff_logged_in()) {
            $staff_language = get_staff_default_language(get_staff_user_id());
            if (!empty($staff_language)) {
                $language = $staff_language;
            }
        }
        
        // Default to English if no language set
        if (empty($language)) {
            $language = 'english';
        }
        
        // Build language file path
        $langFile = module_dir_path(CLAUDE_CONNECTOR_MODULE_NAME) . 'language/' . $language . '/claude_connector_lang.php';
        
        // Fallback to English if language file doesn't exist
        if (!file_exists($langFile)) {
            $langFile = module_dir_path(CLAUDE_CONNECTOR_MODULE_NAME) . 'language/english/claude_connector_lang.php';
        }
        
        // Load the language file
        if (file_exists($langFile)) {
            include($langFile);
            if (isset($lang) && is_array($lang)) {
                $CI->lang->language = array_merge($CI->lang->language, $lang);
            }
        }
    }
}

/**
 * Get module setting helper
 */
if (!function_exists('claude_connector_get_setting')) {
    function claude_connector_get_setting($name, $default = null)
    {
        $CI = &get_instance();
        $CI->db->where('setting_name', $name);
        $row = $CI->db->get(db_prefix() . 'claude_connector_settings')->row();
        
        return $row ? $row->setting_value : $default;
    }
}

/**
 * Check if Claude Connector is enabled
 */
if (!function_exists('claude_connector_is_enabled')) {
    function claude_connector_is_enabled()
    {
        return claude_connector_get_setting('enabled', '1') === '1';
    }
}

/**
 * Log an action from Claude Connector
 */
if (!function_exists('claude_connector_log')) {
    function claude_connector_log($action, $entity_type = null, $entity_id = null, $details = null)
    {
        // Check if logging is enabled
        if (claude_connector_get_setting('log_actions', '1') !== '1') {
            return false;
        }

        $CI = &get_instance();
        
        return $CI->db->insert(db_prefix() . 'claude_connector_logs', [
            'action'      => $action,
            'entity_type' => $entity_type,
            'entity_id'   => $entity_id,
            'details'     => is_array($details) ? json_encode($details) : $details,
            'ip_address'  => $CI->input->ip_address(),
            'user_agent'  => $CI->input->user_agent(),
        ]);
    }
}
